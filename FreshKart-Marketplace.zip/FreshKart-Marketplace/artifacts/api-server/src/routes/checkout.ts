import { createClient } from "@supabase/supabase-js";
import { Router, type IRouter } from "express";
import { PlaceOrderBody, PlaceOrderResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/orders/checkout", async (req, res): Promise<void> => {
  const parsed = PlaceOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Your cart or delivery address is invalid." });
    return;
  }

  const authorization = req.get("authorization");
  const token = authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) {
    res.status(401).json({ error: "Sign in before placing an order." });
    return;
  }

  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;
  if (!supabaseUrl || !supabaseAnonKey) {
    res.status(503).json({
      error: "Supabase is not configured yet. Add the project URL and public key, then try again.",
    });
    return;
  }

  const supabase = createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
      detectSessionInUrl: false,
    },
    global: { headers: { Authorization: `Bearer ${token}` } },
  });

  const { data: authData, error: authError } = await supabase.auth.getUser(token);
  if (authError || !authData.user) {
    res.status(401).json({ error: "Your session has expired. Sign in and try again." });
    return;
  }

  const { data, error } = await supabase.rpc("place_order", {
    p_address_id: parsed.data.addressId,
    p_items: parsed.data.items.map(({ productId, quantity }) => ({
      productId,
      quantity,
    })),
    p_request_id: parsed.data.requestId,
  });

  if (error) {
    const isStockConflict = error.code === "P0001";
    const isInvalidInput = error.code === "22023" || error.code === "42501";
    req.log.warn(
      { code: error.code, userId: authData.user.id },
      "Checkout was rejected",
    );
    res.status(isStockConflict ? 409 : isInvalidInput ? 400 : 500).json({
      error:
        isStockConflict || isInvalidInput
          ? error.message
          : "We could not save your order. No order was placed; please try again.",
    });
    return;
  }

  const receipt = PlaceOrderResponse.safeParse(data);
  if (!receipt.success) {
    req.log.error(
      { userId: authData.user.id },
      "Checkout returned an invalid receipt",
    );
    res.status(500).json({
      error: "We could not confirm the saved order. Please check order history before retrying.",
    });
    return;
  }

  res.status(201).json(receipt.data);
});

export default router;

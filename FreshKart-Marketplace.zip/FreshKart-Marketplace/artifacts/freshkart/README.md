# FreshKart

FreshKart is a fruit delivery storefront with a customer catalog, cart, Supabase Auth, saved delivery addresses, order history, and an admin area for inventory and order status management. The only payment method is **Cash on Delivery (COD)**; the app does not collect or process online payments.

## Current modes

- **Demo mode:** when Supabase configuration is missing, the catalog uses a small, separate frontend demo dataset. Browsing and cart totals work. Sign-in, admin changes, and checkout are blocked; no demo order is ever reported as saved.
- **Live mode:** when the environment variables below are set and the SQL schema is installed, catalog, accounts, addresses, inventory, and orders use Supabase. The demo dataset is not used as a fallback for a live database error.

## Supabase setup

1. Create a Supabase project and copy its **Project URL** and **anon/publishable key** from the project API settings.
2. In Supabase **SQL Editor**, run [`supabase/schema.sql`](./supabase/schema.sql). It creates the tables, customer/admin Row Level Security policies, and the transaction used by checkout. It seeds category names only; it does not seed inventory.
3. Add the same two values to Replit Secrets. The frontend and API server use separate variable names:

   | Replit Secret | Value |
   | --- | --- |
   | `VITE_SUPABASE_URL` | Supabase Project URL |
   | `VITE_SUPABASE_ANON_KEY` | Supabase anon/publishable key |
   | `SUPABASE_URL` | The same Supabase Project URL |
   | `SUPABASE_ANON_KEY` | The same Supabase anon/publishable key |

   The publishable/anon key is designed for browser use and is restricted by RLS. **Never add a Supabase service-role or secret key**; FreshKart does not need one. Do not put credentials in source files or commit a `.env` file. The `VITE_` values are included in the browser build, so they must only contain the public URL and publishable/anon key.
4. Enable Email/Password sign-in in Supabase Auth. For a pilot, choose the email-confirmation behavior that matches your auth-mail setup; the default mail service has sending limits. Add your published domain to Supabase Auth's allowed redirect URLs.
5. Sign up through FreshKart. To grant the first admin, replace the email below and run this once in Supabase SQL Editor as the project owner:

   ```sql
   update public.profiles
   set role = 'admin'
   where id = (
     select id from auth.users where email = 'owner@example.com'
   );
   ```

   Role changes are intentionally unavailable in the frontend. Create other admin accounts only through this trusted SQL-editor step.
6. Sign in as the admin and add the real product inventory, current prices, stock counts, units, and image URLs. Demo products are separate from this inventory and are never copied into the database.

The API server's `POST /api/orders/checkout` forwards the signed-in user's JWT to Supabase and calls `place_order`. The database function takes row locks, reads current prices and stock, checks the customer's saved address, stores an address and product-price snapshot, decrements stock, and writes the order and order items in one transaction. A rejected save is shown as an error, not as a placed order. A request ID prevents duplicate orders when the same checkout request is retried.

## Run and verify

From the workspace root:

```sh
pnpm run typecheck
pnpm --filter @workspace/freshkart run build
```

The FreshKart web artifact and the shared API Server artifact are both part of this project. The web app is served at `/`; checkout is routed to `/api`. Publish the project as a unit so both are available together.

## Free-tier deployment notes

As checked on **October 29, 2026**, Supabase's Free plan lists 50,000 monthly active users, 500 MB database size, 5 GB egress, 5 GB cached egress, 1 GB file storage, and up to two active projects. A Free project pauses after one week without activity. Limits can change; review the [Supabase pricing page](https://supabase.com/pricing) and project usage dashboard before launch. FreshKart does not use Supabase Storage or Realtime, and generated product images are packaged with the web app rather than stored in the database.

Replit's Starter plan currently allows one published app for 30 days, after which it must be republished. The web storefront and API service publish together as one project. Check the current [Replit Starter plan](https://docs.replit.com/billing/plans/starter-plan) and [Publishing costs](https://docs.replit.com/billing/deployment-pricing) before publishing; Replit publishing is not guaranteed to remain free or continuously available on Starter.

To stay within no-cost allowances:

- Keep the Supabase project on Free and monitor database size and egress.
- Use the included COD flow; no card processor, paid email service, storage add-on, or other paid provider is required by the app.
- Use small, optimized product images and avoid uploading image files to Supabase.
- Keep a manual backup of product data and review stock/order activity regularly. Supabase Free projects do not include the paid-plan daily backups listed on the pricing page.
- Expect an inactive Supabase Free project to pause; resume it from Supabase before accepting orders.
- Treat the Free plan as a pilot tier, not a guaranteed always-on production SLA. Review current usage and limits before accepting customer orders.


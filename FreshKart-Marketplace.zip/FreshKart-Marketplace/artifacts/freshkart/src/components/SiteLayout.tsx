import { useState } from 'react';
import type { ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { ArrowRight, Menu, ShoppingBag, X } from 'lucide-react';
import { Brand } from './Brand';
import { useStore } from '../state/StoreContext';

export function SiteLayout({ children, cartCount = 0 }: { children: ReactNode; cartCount?: number }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { live, user, profile } = useStore();
  const nav = [
    { label: 'Shop fruit', href: '/' },
    { label: 'My orders', href: '/orders' },
    ...(profile?.role === 'admin' ? [{ label: 'Shop dashboard', href: '/admin' }] : []),
    { label: user ? 'My account' : 'Sign in', href: '/account' },
  ];
  return <div className="grain min-h-[100dvh]">
    <div className="top-note"><span>Fresh-picked, locally delivered</span><span className="top-note-dot" /> Cash on delivery, always</div>
    <header className="site-header shell">
      <Brand />
      <nav className="desktop-nav" aria-label="Main navigation">
        {nav.map((item) => <Link key={item.href} href={item.href} className={`nav-link ${location === item.href ? 'nav-active' : ''}`} data-testid={`link-nav-${item.href.slice(1) || 'shop'}`}>{item.label}</Link>)}
      </nav>
      <div className="header-actions">
        <Link href="/" className="basket-pill" data-testid="link-cart"><ShoppingBag size={17} /><span>Basket</span><b data-testid="text-cart-count">{cartCount}</b></Link>
        <button className="mobile-menu btn-quiet" onClick={() => setMobileOpen(!mobileOpen)} aria-label={mobileOpen ? 'Close menu' : 'Open menu'} data-testid="button-mobile-menu">{mobileOpen ? <X size={20} /> : <Menu size={20} />}</button>
      </div>
      {mobileOpen && <nav className="mobile-nav" aria-label="Mobile navigation">{nav.map((item) => <Link key={item.href} onClick={() => setMobileOpen(false)} href={item.href} className="mobile-nav-link" data-testid={`link-mobile-${item.href.slice(1) || 'shop'}`}>{item.label}<ArrowRight size={16} /></Link>)}<div className="mobile-mode">{live ? 'LIVE STORE' : 'DEMO CATALOG'}</div></nav>}
    </header>
    {!live && <div className="demo-banner" data-testid="status-demo-mode"><span className="demo-dot" /> DEMO CATALOG <span>Browsing only · checkout, sign-in and admin writes are disabled</span></div>}
    <main>{children}</main>
    <footer className="site-footer"><div className="shell footer-inner"><div><Brand /><p>Good fruit, brought right to your door.</p></div><div className="footer-note"><span>Cash on delivery</span><span>Picked fresh daily</span><span>Right around the corner</span></div><span className="footer-year">© FreshKart</span></div></footer>
  </div>;
}

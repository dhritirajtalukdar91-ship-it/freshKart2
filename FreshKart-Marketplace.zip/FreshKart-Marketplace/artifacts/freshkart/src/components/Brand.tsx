import { Link } from 'wouter';
import { ShoppingBasket } from 'lucide-react';

export function Brand() {
  return <Link href="/" className="brand-link" data-testid="link-brand">
    <span className="brand-mark"><ShoppingBasket size={19} strokeWidth={2.2} /></span>
    <span className="brand-word">fresh<span>kart</span></span>
  </Link>;
}

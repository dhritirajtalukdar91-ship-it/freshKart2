import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { Link } from 'wouter';
import { ArrowDownRight, ArrowRight, Check, CircleAlert, Clock3, LoaderCircle, MapPin, Minus, PackageCheck, Plus, Search, ShieldCheck, ShoppingBasket, Sparkles, Truck } from 'lucide-react';
import { usePlaceOrder } from '@workspace/api-client-react';
import { SiteLayout } from '../components/SiteLayout';
import { useStore } from '../state/StoreContext';
import { supabase } from '../lib/supabase';
import type { Product } from '../data/demoProducts';
import './pages.css';

type ShopProduct = Product;
type Cart = Record<string, number>;
const price = (cents: number) => `₹${(cents / 100).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
const statuses = ['Pending', 'Confirmed', 'Preparing', 'Out for Delivery', 'Delivered'];

export function CatalogPage() {
  const { live, products, categories, loading, error, refreshCatalog, addresses, user, accessToken } = useStore();
  const [cart, setCart] = useState<Cart>({});
  const [category, setCategory] = useState('all');
  const [search, setSearch] = useState('');
  const [cartOpen, setCartOpen] = useState(false);
  const [addressId, setAddressId] = useState('');
  const [checkoutMessage, setCheckoutMessage] = useState('');
  const [checkoutError, setCheckoutError] = useState('');
  const checkout = usePlaceOrder({ request: { headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : {} } });

  const visible = useMemo(() => products.filter((product) => product.is_active && (category === 'all' || product.category_id === category) && `${product.name} ${product.description} ${product.category_name}`.toLowerCase().includes(search.toLowerCase())), [products, category, search]);
  const itemCount = Object.values(cart).reduce((sum, qty) => sum + qty, 0);
  const cartProducts = products.filter((product) => cart[product.id]);
  const total = cartProducts.reduce((sum, product) => sum + product.price_cents * cart[product.id], 0);

  const changeQty = (productId: string, delta: number) => setCart((current) => {
    const next = { ...current };
    const quantity = (next[productId] ?? 0) + delta;
    if (quantity < 1) delete next[productId]; else next[productId] = Math.min(99, quantity);
    return next;
  });
  const addToCart = (product: ShopProduct) => {
    if (!live) { changeQty(product.id, 1); setCheckoutMessage('Added to your demo basket. Demo orders cannot be placed.'); }
    else changeQty(product.id, 1);
    setCheckoutError('');
  };
  const placeOrder = () => {
    setCheckoutError(''); setCheckoutMessage('');
    if (!live || !user || !accessToken) { setCheckoutError('Sign in to a live FreshKart account to place an order.'); return; }
    if (!addressId) { setCheckoutError('Choose a saved delivery address before placing your order.'); return; }
    checkout.mutate({ data: { addressId, requestId: crypto.randomUUID(), items: cartProducts.map((item) => ({ productId: item.id, quantity: cart[item.id] })) } }, {
      onSuccess: (receipt) => { setCart({}); setCheckoutMessage(`Order #${receipt.orderNumber} is in. Pay ₹${(receipt.totalCents / 100).toLocaleString('en-IN')} in cash when it arrives.`); setCartOpen(false); },
      onError: (errorValue) => setCheckoutError(errorValue instanceof Error ? errorValue.message : 'We could not place that order. Please try again.'),
    });
  };

  return <SiteLayout cartCount={itemCount}>
    <section className="hero shell">
      <div className="hero-copy rise">
        <div className="eyebrow"><span className="eyebrow-line" /> GOOD FRUIT. GOOD TIMING.</div>
        <h1 className="serif">The good stuff,<br /><em>right to your door.</em></h1>
        <p>Fruit picked with care and delivered around the corner. Choose what looks good; we’ll bring it fresh.</p>
        <div className="hero-actions"><a className="btn-primary hero-cta" href="#fruit" data-testid="button-shop-fruit">Shop this week <ArrowDownRight size={17} /></a><span className="delivery-promise"><Truck size={16} /> Cash on delivery</span></div>
        <div className="hero-foot"><span>01 — FRESH DAILY</span><span>02 — NO SURPRISES</span><span>03 — PAY AT THE DOOR</span></div>
      </div>
      <div className="hero-art rise rise-delay-1">
        <div className="hero-sun" /><div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" />
        <div className="hero-basket"><img src={products.find((p) => p.id === 'apple')?.image_url || products[1]?.image_url} alt="Fresh apples ready for delivery" data-testid="img-hero-fruit" /><img className="hero-citrus" src={products.find((p) => p.category_id === categories.find((c) => c.name.toLowerCase().includes('citrus'))?.id)?.image_url || products[2]?.image_url} alt="" /></div>
        <div className="hero-stamp"><span>picked</span><b>today</b><small>with care</small></div>
        <div className="hero-art-label"><span>FROM OUR NEIGHBORHOOD</span><span>TO YOUR TABLE <ArrowRight size={12} /></span></div>
      </div>
      <div className="hero-bottomline"><span>GOOD MORNING, FRUIT PEOPLE</span><span>FRESHKART / EST. RIGHT HERE</span></div>
    </section>

    <section className="trust-strip shell" aria-label="Our promise">
      <div><span className="trust-icon"><Sparkles size={17} /></span><b>Picked for today</b><small>We choose the good ones.</small></div>
      <div><span className="trust-icon"><Truck size={17} /></span><b>Easy doorstep drop</b><small>Freshness comes to you.</small></div>
      <div><span className="trust-icon"><ShieldCheck size={17} /></span><b>Cash when it arrives</b><small>Clear, simple COD delivery.</small></div>
    </section>

    <section className="catalog-section shell" id="fruit">
      <div className="section-head">
        <div><div className="eyebrow"><span className="eyebrow-line" /> IN THE FRUIT BOWL</div><h2 className="serif">Today’s good picks<span>.</span></h2><p>Small, fresh selection. Big fruit energy.</p></div>
        <div className="catalog-count"><span>{loading ? '…' : String(visible.length).padStart(2, '0')}</span><small>GOOD THINGS<br />TO CHOOSE</small></div>
      </div>
      {error && <div className="notice notice-error" role="alert" data-testid="status-catalog-error"><CircleAlert size={17} /><span>{error}</span><button onClick={() => void refreshCatalog()} data-testid="button-retry-catalog">Try again</button></div>}
      {checkoutMessage && <div className="notice notice-success" role="status" data-testid="status-checkout-success"><Check size={17} />{checkoutMessage}</div>}
      <div className="catalog-controls">
        <div className="category-tabs"><button className={category === 'all' ? 'category-tab selected' : 'category-tab'} onClick={() => setCategory('all')} data-testid="filter-category-all">All fruit</button>{categories.map((item) => <button key={item.id} className={category === item.id ? 'category-tab selected' : 'category-tab'} onClick={() => setCategory(item.id)} data-testid={`filter-category-${item.id}`}>{item.name}</button>)}</div>
        <label className="search-box"><Search size={16} /><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Find your favourite" aria-label="Search fruit" data-testid="input-search-fruit" /></label>
      </div>
      {loading ? <div className="product-grid" data-testid="loading-products">{[1,2,3,4].map((n) => <div className="product-skeleton" key={n}><div /><span /><i /></div>)}</div> : visible.length ? <div className="product-grid" data-testid="grid-products">{visible.map((product, index) => <article className={`product-card rise ${index % 3 === 1 ? 'rise-delay-1' : ''}`} key={product.id} data-testid={`card-product-${product.id}`}>
        <div className={`product-visual visual-${index % 4}`}><span className="product-category">{product.category_name || 'Fresh today'}</span>{product.image_url ? <img className="product-image" src={product.image_url} alt={product.name} data-testid={`img-product-${product.id}`} /> : <div className="no-photo"><ShoppingBasket size={30} /><span>Fresh today</span></div>}<span className="fresh-badge">JUST IN</span></div>
        <div className="product-info"><div className="product-heading"><h3>{product.name}</h3><span className="availability">{product.stock > 0 ? 'In today' : 'Sold out'}</span></div><p>{product.description}</p><div className="product-buy"><div><b>{price(product.price_cents)}</b><small> / {product.unit}</small></div><button className="add-button" onClick={() => addToCart(product)} disabled={product.stock < 1} data-testid={`button-add-${product.id}`} aria-label={`Add ${product.name} to basket`}><Plus size={16} /><span>Add</span></button></div></div>
      </article>)}</div> : <div className="empty-state"><span className="empty-doodle"><Search size={24} /></span><h3>No fruit by that name</h3><p>Try another search, or clear the filter to see the whole basket.</p><button className="btn-quiet reset-filter" onClick={() => { setSearch(''); setCategory('all'); }} data-testid="button-clear-filters">Show all fruit</button></div>}
      <div className="catalog-endnote"><span>THAT’S THE GOOD STUFF</span><span>Selected with a little extra care <ArrowRight size={13} /></span></div>
    </section>

    <section className="closing-note shell"><div className="closing-mark">F.</div><div><p className="eyebrow">A LITTLE PROMISE FROM US</p><h2 className="serif">Good fruit. Clear terms.<br /><em>No funny business.</em></h2></div><div className="closing-detail"><p>We keep the selection simple and the delivery straightforward. Pay in cash when your order reaches your door.</p><Link href="/account" data-testid="link-account-address">Add a delivery address <ArrowRight size={15} /></Link></div></section>

    <div className={`cart-backdrop ${cartOpen ? 'is-open' : ''}`} onClick={() => setCartOpen(false)} aria-hidden={!cartOpen} />
    <aside className={`cart-drawer ${cartOpen ? 'is-open' : ''}`} aria-label="Basket" aria-hidden={!cartOpen}>
      <div className="cart-head"><div><span className="eyebrow">YOUR LITTLE HAUL</span><h2 className="serif">Basket <span>({itemCount})</span></h2></div><button className="icon-button" onClick={() => setCartOpen(false)} aria-label="Close basket" data-testid="button-close-cart"><span>×</span></button></div>
      {!cartProducts.length ? <div className="cart-empty"><span className="empty-doodle"><ShoppingBasket size={23} /></span><h3>Your basket is waiting</h3><p>Add a few fresh picks and we’ll take it from here.</p><button className="btn-primary cart-shop" onClick={() => setCartOpen(false)} data-testid="button-cart-shop">Browse fruit <ArrowRight size={15} /></button></div> : <>
        <div className="cart-list">{cartProducts.map((product) => <div className="cart-line" key={product.id} data-testid={`row-cart-${product.id}`}><img src={product.image_url} alt="" /><div className="cart-line-main"><b>{product.name}</b><small>{price(product.price_cents)} / {product.unit}</small><div className="quantity-control"><button onClick={() => changeQty(product.id, -1)} aria-label={`Remove one ${product.name}`} data-testid={`button-decrease-${product.id}`}><Minus size={12} /></button><span data-testid={`text-quantity-${product.id}`}>{cart[product.id]}</span><button onClick={() => changeQty(product.id, 1)} aria-label={`Add one ${product.name}`} data-testid={`button-increase-${product.id}`}><Plus size={12} /></button></div></div><strong>{price(product.price_cents * cart[product.id])}</strong></div>)}</div>
        <div className="cart-summary"><div><span>Fruit total</span><b>{price(total)}</b></div><div><span>Delivery</span><b>At the door</b></div><div className="cart-total"><span>Pay on delivery</span><b>{price(total)}</b></div></div>
        {checkoutError && <div className="cart-error" role="alert" data-testid="status-checkout-error">{checkoutError}</div>}
        {!live ? <div className="demo-checkout-block" data-testid="status-checkout-blocked"><b>Demo basket only</b><span>Checkout is blocked until the live store is connected.</span></div> : !user ? <Link className="btn-primary checkout-button" href="/account" data-testid="link-checkout-signin">Sign in to check out <ArrowRight size={15} /></Link> : addresses.length ? <>
          <label className="address-select-label">Deliver to <select value={addressId} onChange={(event) => setAddressId(event.target.value)} className="input-field" data-testid="select-checkout-address"><option value="">Choose a saved address</option>{addresses.map((address) => <option key={address.id} value={address.id}>{address.label} · {address.line1}, {address.city}</option>)}</select></label>
          <button className="btn-primary checkout-button" onClick={placeOrder} disabled={checkout.isPending} data-testid="button-place-order">{checkout.isPending ? <><LoaderCircle className="spin" size={16} /> Placing order…</> : <>Place COD order <ArrowRight size={15} /></>}</button>
        </> : <div className="demo-checkout-block"><b>No saved delivery address</b><Link href="/account" data-testid="link-add-address-checkout">Add one in your account <ArrowRight size={14} /></Link></div>}
        <p className="cod-note"><ShieldCheck size={14} /> Cash only, payable when your fruit arrives.</p>
      </>}
    </aside>
    <button className={`floating-cart ${itemCount ? 'has-items' : ''}`} onClick={() => setCartOpen(true)} data-testid="button-open-cart"><ShoppingBasket size={19} /><span>{itemCount ? `Your basket · ${itemCount}` : 'Your basket'}</span>{itemCount > 0 && <b>{price(total)}</b>}</button>
  </SiteLayout>;
}

const emptyAddress = { label: 'Home', recipient_name: '', phone: '', line1: '', line2: '', city: '', state: '', pincode: '', is_default: true };

export function AccountPage() {
  const { live, user, profile, addresses, loading, signIn, signUp, signOut, saveAddress, refreshAddresses } = useStore();
  const [mode, setMode] = useState<'login' | 'signup'>('signup');
  const [form, setForm] = useState({ email: '', password: '', fullName: '' });
  const [address, setAddress] = useState(emptyAddress);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const updateForm = (key: keyof typeof form, value: string) => setForm((current) => ({ ...current, [key]: value }));
  const updateAddress = <K extends keyof typeof emptyAddress>(key: K, value: typeof emptyAddress[K]) => setAddress((current) => ({ ...current, [key]: value }));
  const submitAuth = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError(''); setMessage('');
    try {
      if (mode === 'signup') {
        const signedIn = await signUp(form.email, form.password, form.fullName);
        setMessage(signedIn ? 'Your account is ready. Add a delivery address below.' : 'Check your email to confirm your account, then sign in.');
      }
      else { await signIn(form.email, form.password); setMessage('You’re signed in. Welcome back.'); }
    } catch (e) { setError(e instanceof Error ? e.message : 'We could not complete that request. Try again.'); }
    finally { setBusy(false); }
  };
  const submitAddress = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError(''); setMessage('');
    try { await saveAddress(address); setAddress(emptyAddress); setMessage('Delivery address saved.'); await refreshAddresses(); }
    catch (e) { setError(e instanceof Error ? e.message : 'Could not save this address. Please try again.'); }
    finally { setBusy(false); }
  };

  return <SiteLayout><section className="inner-page shell">
    <div className="page-kicker"><span>FRESHKART / YOUR ACCOUNT</span><span>01 — ACCOUNT & DELIVERY</span></div>
    <div className="page-title-row"><div><p className="eyebrow"><span className="eyebrow-line" /> YOUR CORNER OF THE SHOP</p><h1 className="serif">{user ? 'Good to have you.' : 'Let’s get you home.'}</h1><p className="page-subtitle">Your account and delivery details, all in one easy place.</p></div><div className="page-illustration account-illustration"><MapPin size={28} /><span>to your<br />doorstep</span></div></div>
    {!live && <div className="notice notice-demo"><CircleAlert size={17} /><span><b>Demo catalog only.</b> Sign-up, sign-in and address saving are unavailable until the live store is connected.</span></div>}
    {(error || message) && <div className={`notice ${error ? 'notice-error' : 'notice-success'}`} role={error ? 'alert' : 'status'} data-testid={error ? 'status-account-error' : 'status-account-message'}>{error ? <CircleAlert size={17} /> : <Check size={17} />}{error || message}</div>}
    <div className="account-columns">
      <section className="paper-panel account-panel">
        {loading ? <div className="loading-line">Checking your account…</div> : user ? <div className="signed-in-card" data-testid="panel-signed-in"><div className="profile-avatar">{(profile?.full_name || user.email || 'F').slice(0,1).toUpperCase()}</div><div><span className="eyebrow">SIGNED IN AS</span><h2>{profile?.full_name || user.email}</h2><p>{user.email}</p></div><button className="btn-quiet account-signout" onClick={() => void signOut().catch((e) => setError(e.message))} data-testid="button-sign-out">Sign out</button></div> : <>
          <div className="account-tabs"><button className={mode === 'signup' ? 'account-tab on' : 'account-tab'} onClick={() => { setMode('signup'); setError(''); }} data-testid="tab-signup">Create account</button><button className={mode === 'login' ? 'account-tab on' : 'account-tab'} onClick={() => { setMode('login'); setError(''); }} data-testid="tab-login">Sign in</button></div>
          <h2 className="serif account-form-heading">{mode === 'signup' ? 'A simpler fruit run.' : 'Welcome back.'}</h2><p className="account-form-copy">{mode === 'signup' ? 'Save your delivery details and make the next order even quicker.' : 'Your saved delivery details are ready when you are.'}</p>
          <form onSubmit={submitAuth} className="form-stack">
            {mode === 'signup' && <label>Your name<input className="input-field" value={form.fullName} onChange={(e) => updateForm('fullName', e.target.value)} autoComplete="name" required minLength={2} placeholder="How should we greet you?" data-testid="input-full-name" /></label>}
            <label>Email address<input className="input-field" type="email" value={form.email} onChange={(e) => updateForm('email', e.target.value)} autoComplete="email" required placeholder="you@example.com" data-testid="input-account-email" /></label>
            <label>Password<input className="input-field" type="password" value={form.password} onChange={(e) => updateForm('password', e.target.value)} autoComplete={mode === 'signup' ? 'new-password' : 'current-password'} required minLength={6} placeholder="At least 6 characters" data-testid="input-account-password" /></label>
            <button className="btn-primary form-submit" disabled={busy || !live} data-testid="button-auth-submit">{busy ? 'One moment…' : mode === 'signup' ? 'Create my account' : 'Sign in'} <ArrowRight size={16} /></button>
          </form>
          {!live && <p className="blocked-caption">Account access is intentionally blocked in demo mode.</p>}
        </>}
      </section>
      <section className="paper-panel address-panel">
        <div className="panel-heading"><div><span className="eyebrow">DELIVERY DETAILS</span><h2 className="serif">Your saved addresses</h2></div><span className="address-count">{addresses.length.toString().padStart(2, '0')}</span></div>
        {!user ? <div className="address-empty"><MapPin size={24} /><h3>One less thing next time</h3><p>Sign in or create an account to keep a delivery address handy.</p></div> : addresses.length ? <div className="saved-addresses" data-testid="list-addresses">{addresses.map((item) => <article className="saved-address" key={item.id} data-testid={`card-address-${item.id}`}><div className="saved-address-icon"><MapPin size={17} /></div><div><div className="saved-address-title">{item.label}{item.is_default && <span>DEFAULT</span>}</div><p>{item.recipient_name} · {item.phone}<br />{item.line1}{item.line2 ? `, ${item.line2}` : ''}<br />{item.city}, {item.state} {item.pincode}</p></div></article>)}</div> : <div className="address-empty"><MapPin size={24} /><h3>Nothing saved yet</h3><p>Add your doorstep once; your next basket will be faster.</p></div>}
        {user && <form className="form-stack address-form" onSubmit={submitAddress}>
          <div className="address-form-top"><h3>Add a delivery address</h3><label className="default-check"><input type="checkbox" checked={address.is_default} onChange={(e) => updateAddress('is_default', e.target.checked)} data-testid="checkbox-default-address" /> Set as default</label></div>
          <div className="form-grid"><label>Label<input className="input-field" value={address.label} onChange={(e) => updateAddress('label', e.target.value)} required placeholder="Home, work…" data-testid="input-address-label" /></label><label>Recipient name<input className="input-field" value={address.recipient_name} onChange={(e) => updateAddress('recipient_name', e.target.value)} required placeholder="Name at the door" data-testid="input-recipient-name" /></label></div>
          <div className="form-grid"><label>Phone<input className="input-field" type="tel" value={address.phone} onChange={(e) => updateAddress('phone', e.target.value)} required placeholder="10-digit number" data-testid="input-address-phone" /></label><label>PIN code<input className="input-field" inputMode="numeric" value={address.pincode} onChange={(e) => updateAddress('pincode', e.target.value)} required placeholder="560 001" data-testid="input-address-pincode" /></label></div>
          <label>Address line 1<input className="input-field" value={address.line1} onChange={(e) => updateAddress('line1', e.target.value)} required placeholder="Flat, building and street" data-testid="input-address-line1" /></label>
          <label>Address line 2 <span className="optional">optional</span><input className="input-field" value={address.line2} onChange={(e) => updateAddress('line2', e.target.value)} placeholder="Landmark or area" data-testid="input-address-line2" /></label>
          <div className="form-grid"><label>City<input className="input-field" value={address.city} onChange={(e) => updateAddress('city', e.target.value)} required placeholder="City" data-testid="input-address-city" /></label><label>State<input className="input-field" value={address.state} onChange={(e) => updateAddress('state', e.target.value)} required placeholder="State" data-testid="input-address-state" /></label></div>
          <button className="btn-primary form-submit" disabled={busy || !live} data-testid="button-save-address">{busy ? 'Saving…' : 'Save address'} <ArrowRight size={16} /></button>
          {!live && <p className="blocked-caption">Saving addresses is disabled in demo mode.</p>}
        </form>}
      </section>
    </div>
  </section></SiteLayout>;
}

export function OrdersPage() {
  const { live, user, loading } = useStore();
  const [orders, setOrders] = useState<any[]>([]);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');
  const loadOrders = async () => {
    if (!supabase || !user) { setOrders([]); setBusy(false); return; }
    setBusy(true); setError('');
    const { data, error: loadError } = await supabase.from('orders').select('*, order_items(*)').eq('user_id', user.id).order('created_at', { ascending: false });
    if (loadError) setError(`Could not load your order history: ${loadError.message}`);
    else setOrders(data ?? []);
    setBusy(false);
  };
  useEffect(() => { if (!loading) void loadOrders(); }, [user?.id, loading]);
  return <SiteLayout><section className="inner-page shell">
    <div className="page-kicker"><span>FRESHKART / YOUR ORDERS</span><span>02 — ORDER HISTORY</span></div>
    <div className="page-title-row"><div><p className="eyebrow"><span className="eyebrow-line" /> YOUR FRUIT, ON ITS WAY</p><h1 className="serif">Order history<span>.</span></h1><p className="page-subtitle">Everything you’ve ordered, with the latest delivery status.</p></div><div className="page-illustration"><PackageCheck size={29} /><span>no surprises,<br />just good fruit</span></div></div>
    {!live && <div className="notice notice-demo" data-testid="status-orders-blocked"><CircleAlert size={17} /><span><b>Demo catalog only.</b> Order history is unavailable because no live account is connected.</span></div>}
    {!user && live && <div className="paper-panel orders-signin"><Clock3 size={25} /><h2 className="serif">Your orders will be right here.</h2><p>Sign in to see your delivery history and current order updates.</p><Link className="btn-primary" href="/account" data-testid="link-orders-signin">Sign in to your account <ArrowRight size={15} /></Link></div>}
    {user && (busy || loading) ? <div className="orders-loading" data-testid="loading-orders">{[1,2].map((i) => <div className="order-skeleton" key={i}><span /><span /><i /></div>)}</div> : user && error ? <div className="notice notice-error" role="alert" data-testid="status-orders-error"><CircleAlert size={17} />{error}<button onClick={() => void loadOrders()} data-testid="button-retry-orders">Try again</button></div> : user && !orders.length ? <div className="paper-panel orders-empty" data-testid="empty-orders"><span className="empty-doodle"><ShoppingBasket size={24} /></span><h2 className="serif">No orders just yet.</h2><p>When you find something good in the fruit bowl, we’ll keep the details here.</p><Link href="/" className="btn-primary" data-testid="link-shop-from-orders">Pick some fruit <ArrowRight size={15} /></Link></div> : user && <div className="orders-list" data-testid="list-orders">{orders.map((order) => <article className="order-card paper-panel" key={order.id} data-testid={`card-order-${order.id}`}>
      <div className="order-card-top"><div><span className="eyebrow">ORDER #{order.order_number}</span><p>{new Date(order.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p></div><span className={`status-pill status-${String(order.status).toLowerCase().replaceAll(' ', '-')}`} data-testid={`status-order-${order.id}`}><span />{order.status}</span></div>
      <div className="order-items">{(order.order_items ?? []).map((item: any) => <div className="order-item" key={item.id}><span>{item.quantity} × {item.product_name_snapshot}</span><span>{price(item.unit_price_cents * item.quantity)}</span></div>)}</div>
      <div className="order-card-bottom"><div className="order-delivery"><MapPin size={15} /><span>{typeof order.shipping_address === 'string' ? order.shipping_address : [order.shipping_address?.line1, order.shipping_address?.city, order.shipping_address?.pincode].filter(Boolean).join(', ') || 'Saved delivery address'}</span></div><div><span>COD · Pay on arrival</span><b>{price(order.total_cents)}</b></div></div>
      <div className="status-track">{statuses.map((status, index) => { const current = statuses.indexOf(order.status); return <div key={status} className={`track-step ${index <= current ? 'track-done' : ''}`}><span className="track-dot">{index < current ? <Check size={10} /> : null}</span><small>{status}</small></div>; })}</div>
    </article>)}</div>}
  </section></SiteLayout>;
}

export function AdminPage() {
  const { live, user, profile, loading, refreshCatalog, categories } = useStore();
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [tab, setTab] = useState<'products' | 'orders'>('products');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState<Product | null | undefined>(undefined);
  const [draft, setDraft] = useState({ name: '', slug: '', description: '', category_id: '', price_cents: '', unit: '', stock: '', image_url: '', is_active: true });
  const [savedMessage, setSavedMessage] = useState('');
  const admin = live && !!user && profile?.role === 'admin';

  const loadDashboard = async () => {
    if (!supabase || !admin) return;
    setBusy(true); setError('');
    const [productResult, orderResult] = await Promise.all([
      supabase.from('products').select('*, categories(name)').order('name'),
      supabase.from('orders').select('*, order_items(*)').order('created_at', { ascending: false }),
    ]);
    if (productResult.error) setError(`Products could not be loaded: ${productResult.error.message}`);
    else setAllProducts((productResult.data ?? []).map((item: any) => ({ ...item, category_name: item.categories?.name ?? item.category_name ?? '' })) as Product[]);
    if (orderResult.error) setError(`Orders could not be loaded: ${orderResult.error.message}`);
    else setOrders(orderResult.data ?? []);
    setBusy(false);
  };
  useEffect(() => { if (!loading && admin) void loadDashboard(); }, [admin, loading]);
  const beginCreate = () => { setEditing(null); setDraft({ name: '', slug: '', description: '', category_id: '', price_cents: '', unit: 'kg', stock: '', image_url: '', is_active: true }); setSavedMessage(''); };
  const beginEdit = (product: Product) => { setEditing(product); setDraft({ name: product.name, slug: product.slug, description: product.description, category_id: product.category_id, price_cents: String(product.price_cents), unit: product.unit, stock: String(product.stock), image_url: product.image_url, is_active: product.is_active }); setSavedMessage(''); };
  const saveProduct = async (event: FormEvent) => {
    event.preventDefault(); if (!supabase || !admin) return;
    setBusy(true); setError('');
    const payload = { ...draft, price_cents: Math.round(Number(draft.price_cents) * 100), stock: Number(draft.stock), slug: draft.slug || draft.name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') };
    const result = editing ? await supabase.from('products').update(payload).eq('id', editing.id) : await supabase.from('products').insert(payload);
    if (result.error) setError(`Could not save product: ${result.error.message}`);
    else { setSavedMessage(editing ? 'Product details saved.' : 'Product added to the catalog.'); setEditing(null); await loadDashboard(); await refreshCatalog(); }
    setBusy(false);
  };
  const toggleProduct = async (product: Product) => {
    if (!supabase || !admin) return;
    const { error: writeError } = await supabase.from('products').update({ is_active: !product.is_active }).eq('id', product.id);
    if (writeError) setError(`Could not update product: ${writeError.message}`); else { setSavedMessage(`${product.name} ${product.is_active ? 'hidden from' : 'shown in'} the shop.`); await loadDashboard(); await refreshCatalog(); }
  };
  const deleteProduct = async (product: Product) => {
    if (!supabase || !admin || !window.confirm(`Delete ${product.name} from the catalog? This cannot be undone.`)) return;
    const { error: deleteError } = await supabase.from('products').delete().eq('id', product.id);
    if (deleteError) setError(`Could not delete product: ${deleteError.message}`);
    else { setSavedMessage(`${product.name} was removed from the catalog.`); await loadDashboard(); await refreshCatalog(); }
  };
  const updateStatus = async (orderId: string, status: string) => {
    if (!supabase || !admin) return;
    setBusy(true); const { error: writeError } = await supabase.from('orders').update({ status }).eq('id', orderId);
    if (writeError) setError(`Could not update order status: ${writeError.message}`); else { setSavedMessage('Order status updated.'); await loadDashboard(); }
    setBusy(false);
  };
  return <SiteLayout><section className="inner-page shell">
    <div className="page-kicker"><span>FRESHKART / SHOP DASHBOARD</span><span>03 — ADMIN</span></div>
    <div className="page-title-row"><div><p className="eyebrow"><span className="eyebrow-line" /> BACK OF THE FRUIT STAND</p><h1 className="serif">Shop dashboard<span>.</span></h1><p className="page-subtitle">Keep the catalog tidy and every order moving.</p></div><div className="admin-mark"><span>FRESH<br />TODAY</span><ShoppingBasket size={24} /></div></div>
    {!live && <div className="notice notice-demo" data-testid="status-admin-blocked"><CircleAlert size={17} /><span><b>Admin writes are blocked.</b> This is demo data, not a live catalog. Connect Supabase and sign in with an admin account.</span></div>}
    {live && !user && <div className="paper-panel admin-gate"><ShieldCheck size={28} /><h2 className="serif">Staff access only.</h2><p>Sign in with an authorized shop account to manage products and orders.</p><Link className="btn-primary" href="/account" data-testid="link-admin-signin">Sign in <ArrowRight size={15} /></Link></div>}
    {live && user && profile?.role !== 'admin' && !loading && <div className="paper-panel admin-gate"><ShieldCheck size={28} /><h2 className="serif">This counter is for shop staff.</h2><p>Your signed-in account does not have the admin role. Product and order data stays protected.</p><Link href="/" className="btn-quiet" data-testid="link-admin-shop">Back to the fruit <ArrowRight size={15} /></Link></div>}
    {admin && <><div className="admin-stats"><div><span>LIVE PRODUCTS</span><b>{allProducts.filter((p) => p.is_active).length.toString().padStart(2, '0')}</b></div><div><span>ORDERS TO MOVE</span><b>{orders.filter((o) => o.status !== 'Delivered').length.toString().padStart(2, '0')}</b></div><div><span>ALL ORDERS</span><b>{orders.length.toString().padStart(2, '0')}</b></div></div>
      <div className="admin-toolbar"><div className="admin-tabs"><button onClick={() => setTab('products')} className={tab === 'products' ? 'admin-tab active' : 'admin-tab'} data-testid="tab-admin-products">Products <span>{allProducts.length}</span></button><button onClick={() => setTab('orders')} className={tab === 'orders' ? 'admin-tab active' : 'admin-tab'} data-testid="tab-admin-orders">Orders <span>{orders.length}</span></button></div>{tab === 'products' && <button className="btn-primary add-product-button" onClick={beginCreate} data-testid="button-new-product"><Plus size={16} /> Add product</button>}</div>
      {savedMessage && <div className="notice notice-success" role="status" data-testid="status-admin-success"><Check size={16} />{savedMessage}<button onClick={() => setSavedMessage('')} aria-label="Dismiss message" data-testid="button-dismiss-admin-message">Dismiss</button></div>}
      {error && <div className="notice notice-error" role="alert" data-testid="status-admin-error"><CircleAlert size={17} />{error}<button onClick={() => void loadDashboard()} data-testid="button-retry-admin">Try again</button></div>}
      {editing !== undefined && tab === 'products' && <form className="paper-panel product-editor" onSubmit={saveProduct}><div className="panel-heading"><div><span className="eyebrow">{editing ? 'EDIT THE DETAILS' : 'ADD TO THE FRUIT BOWL'}</span><h2 className="serif">{editing ? editing.name : 'A new good thing'}</h2></div><button type="button" className="btn-quiet" onClick={() => setEditing(null)} data-testid="button-cancel-product">Cancel</button></div>
        <div className="form-grid"><label>Product name<input className="input-field" required value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} data-testid="input-product-name" /></label><label>Slug<input className="input-field" value={draft.slug} onChange={(e) => setDraft({ ...draft, slug: e.target.value })} placeholder="Generated from name if blank" data-testid="input-product-slug" /></label></div>
        <label>Description<input className="input-field" value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} data-testid="input-product-description" /></label>
        <div className="form-grid"><label>Category<select className="input-field" required value={draft.category_id} onChange={(e) => setDraft({ ...draft, category_id: e.target.value })} data-testid="select-product-category"><option value="">Choose a category</option>{categories.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><label>Unit<input className="input-field" required value={draft.unit} onChange={(e) => setDraft({ ...draft, unit: e.target.value })} placeholder="kg, dozen…" data-testid="input-product-unit" /></label></div>
        <div className="form-grid"><label>Price in rupees<input className="input-field" type="number" min="0.01" step="0.01" required value={draft.price_cents} onChange={(e) => setDraft({ ...draft, price_cents: e.target.value })} data-testid="input-product-price" /></label><label>Stock quantity<input className="input-field" type="number" min="0" step="1" required value={draft.stock} onChange={(e) => setDraft({ ...draft, stock: e.target.value })} data-testid="input-product-stock" /></label></div>
        <label>Image URL<input className="input-field" type="url" value={draft.image_url} onChange={(e) => setDraft({ ...draft, image_url: e.target.value })} placeholder="Use a product image address" data-testid="input-product-image" /></label>
        <label className="default-check"><input type="checkbox" checked={draft.is_active} onChange={(e) => setDraft({ ...draft, is_active: e.target.checked })} data-testid="checkbox-product-active" /> Visible in the shop</label>
        <button className="btn-primary form-submit" disabled={busy} data-testid="button-save-product">{busy ? 'Saving…' : editing ? 'Save product' : 'Add product'} <ArrowRight size={16} /></button>
      </form>}
      {busy && !allProducts.length ? <div className="loading-line" data-testid="loading-admin">Loading shop dashboard…</div> : tab === 'products' ? <div className="admin-product-list" data-testid="list-admin-products">{allProducts.map((product) => <article className="admin-product-row" key={product.id} data-testid={`row-admin-product-${product.id}`}><div className="admin-product-image">{product.image_url ? <img src={product.image_url} alt="" /> : <ShoppingBasket size={20} />}</div><div className="admin-product-name"><b>{product.name}</b><span>{product.category_name || product.category_id} · {price(product.price_cents)} / {product.unit}</span></div><span className={`stock-status ${product.stock < 5 ? 'stock-low' : ''}`}>{product.stock} in stock</span><span className={`active-status ${product.is_active ? 'is-active' : ''}`}>{product.is_active ? 'Visible' : 'Hidden'}</span><div className="row-actions"><button className="btn-quiet" onClick={() => beginEdit(product)} data-testid={`button-edit-${product.id}`}>Edit</button><button className="btn-quiet" onClick={() => void toggleProduct(product)} data-testid={`button-toggle-${product.id}`}>{product.is_active ? 'Hide' : 'Show'}</button><button className="btn-quiet" onClick={() => void deleteProduct(product)} data-testid={`button-delete-${product.id}`}>Delete</button></div></article>)}</div> : <div className="admin-orders" data-testid="list-admin-orders">{orders.length ? orders.map((order) => <article className="admin-order-row paper-panel" key={order.id} data-testid={`row-admin-order-${order.id}`}><div className="admin-order-head"><div><span className="eyebrow">ORDER #{order.order_number}</span><p>{new Date(order.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p></div><strong>{price(order.total_cents)}</strong></div><div className="admin-order-items">{(order.order_items ?? []).map((item: any) => `${item.quantity} × ${item.product_name_snapshot}`).join(' · ')}</div><div className="admin-order-bottom"><span className="cod-inline">COD · cash at delivery</span><label className="status-select-label">Order status<select className="input-field" value={order.status} onChange={(e) => void updateStatus(order.id, e.target.value)} disabled={busy} data-testid={`select-order-status-${order.id}`}>{statuses.map((status) => <option key={status} value={status}>{status}</option>)}</select></label></div></article>) : <div className="empty-state"><h3>No orders in the queue.</h3><p>New customer orders will show up here.</p></div>}</div>}
    </>}
  </section></SiteLayout>;
}

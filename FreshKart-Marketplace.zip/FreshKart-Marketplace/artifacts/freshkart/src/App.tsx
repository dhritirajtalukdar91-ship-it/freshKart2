import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useHealthCheck, getHealthCheckQueryKey } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { CatalogPage, AccountPage, OrdersPage, AdminPage } from './pages/ShopPages';
import { StoreProvider } from './state/StoreContext';
import './components/ui/AppStyles.css';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

function HealthSignal() {
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), refetchInterval: 60_000, retry: 1 } });
  if (health.isError) return <div className="health-warning" role="status" data-testid="status-server-health">Order service is having trouble connecting. Browsing is still available.</div>;
  return null;
}

function Router() {
  return <RoutedErrorBoundary><StoreProvider><HealthSignal /><Switch>
    <Route path="/" component={CatalogPage} />
    <Route path="/account" component={AccountPage} />
    <Route path="/orders" component={OrdersPage} />
    <Route path="/admin" component={AdminPage} />
    <Route component={NotFound} />
  </Switch></StoreProvider></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;

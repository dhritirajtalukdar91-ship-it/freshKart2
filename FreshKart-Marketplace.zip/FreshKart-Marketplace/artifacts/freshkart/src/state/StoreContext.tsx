import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { User } from '@supabase/supabase-js';
import { demoCategories, demoProducts, type Product } from '../data/demoProducts';
import { isLiveMode, supabase, type Address, type Profile } from '../lib/supabase';

interface StoreValue {
  live: boolean;
  user: User | null;
  accessToken: string | null;
  profile: Profile | null;
  products: Product[];
  categories: { id: string; name: string; slug: string }[];
  addresses: Address[];
  loading: boolean;
  error: string;
  refreshCatalog: () => Promise<void>;
  refreshAddresses: () => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, fullName: string) => Promise<boolean>;
  signOut: () => Promise<void>;
  saveAddress: (address: Omit<Address, 'id' | 'user_id'>) => Promise<void>;
}

const StoreContext = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [products, setProducts] = useState<Product[]>(isLiveMode ? [] : demoProducts);
  const [categories, setCategories] = useState(isLiveMode ? [] : demoCategories);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [loading, setLoading] = useState(isLiveMode);
  const [error, setError] = useState('');

  const refreshCatalog = async () => {
    if (!supabase) return;
    const [productResult, categoryResult] = await Promise.all([
      supabase.from('products').select('*, categories(name)').eq('is_active', true).order('name'),
      supabase.from('categories').select('*').order('name'),
    ]);
    if (productResult.error) { setError(`Could not load today's fruit: ${productResult.error.message}`); return; }
    const normalized = (productResult.data ?? []).map((item: any) => ({
      ...item,
      category_name: item.category_name ?? item.categories?.name ?? '',
      image_url: item.image_url ?? '',
    })) as Product[];
    setProducts(normalized);
    if (categoryResult.data) setCategories(categoryResult.data);
    setError('');
  };

  const refreshAddresses = async () => {
    if (!supabase || !user) { setAddresses([]); return; }
    const { data, error: addressError } = await supabase.from('addresses').select('*').eq('user_id', user.id).order('is_default', { ascending: false });
    if (addressError) { setError(`Could not load saved addresses: ${addressError.message}`); return; }
    setAddresses((data ?? []) as Address[]);
  };

  const loadProfile = async (current: User | null, token?: string | null) => {
    setUser(current);
    setAccessToken(token ?? null);
    if (!current || !supabase) { setProfile(null); setAddresses([]); return; }
    const { data, error: profileError } = await supabase.from('profiles').select('id,full_name,role').eq('id', current.id).maybeSingle();
    setProfile(profileError ? null : data as Profile | null);
  };

  useEffect(() => {
    if (!supabase) { setLoading(false); return; }
    let mounted = true;
    supabase.auth.getSession().then(async ({ data }) => {
      if (!mounted) return;
      await loadProfile(data.session?.user ?? null, data.session?.access_token);
      await refreshCatalog();
      setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (mounted) void loadProfile(session?.user ?? null, session?.access_token);
    });
    return () => { mounted = false; listener.subscription.unsubscribe(); };
  }, []);

  useEffect(() => { void refreshAddresses(); }, [user?.id]);

  const signIn = async (email: string, password: string) => {
    if (!supabase) throw new Error('Sign-in is unavailable in demo mode. Add both Supabase browser settings to connect an account.');
    const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
    if (authError) throw authError;
  };
  const signUp = async (email: string, password: string, fullName: string) => {
    if (!supabase) throw new Error('Account creation is unavailable in demo mode. Add both Supabase browser settings to connect an account.');
    const { data, error: authError } = await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName } } });
    if (authError) throw authError;
    // The database auth trigger creates the customer profile. The browser must
    // not insert or assign roles directly.
    if (data.user && data.session) await loadProfile(data.user, data.session.access_token);
    return Boolean(data.session);
  };
  const signOut = async () => {
    if (!supabase) return;
    const { error: authError } = await supabase.auth.signOut();
    if (authError) throw authError;
    setUser(null); setAccessToken(null); setProfile(null); setAddresses([]);
  };
  const saveAddress = async (address: Omit<Address, 'id' | 'user_id'>) => {
    if (!supabase || !user) throw new Error('Sign in to save a delivery address.');
    let previousDefaultId: string | null = null;
    if (address.is_default) {
      const { data: previous, error: lookupError } = await supabase
        .from('addresses')
        .select('id')
        .eq('user_id', user.id)
        .eq('is_default', true)
        .maybeSingle();
      if (lookupError) throw lookupError;
      previousDefaultId = previous?.id ?? null;
      if (previousDefaultId) {
        const { error: unsetError } = await supabase
          .from('addresses')
          .update({ is_default: false })
          .eq('id', previousDefaultId)
          .eq('user_id', user.id);
        if (unsetError) throw unsetError;
      }
    }
    const { error: addressError } = await supabase
      .from('addresses')
      .insert({ ...address, user_id: user.id });
    if (addressError) {
      if (previousDefaultId) {
        await supabase
          .from('addresses')
          .update({ is_default: true })
          .eq('id', previousDefaultId)
          .eq('user_id', user.id);
      }
      throw addressError;
    }
    await refreshAddresses();
  };

  const value = useMemo(() => ({ live: isLiveMode, user, accessToken, profile, products, categories, addresses, loading, error, refreshCatalog, refreshAddresses, signIn, signUp, signOut, saveAddress }), [user, accessToken, profile, products, categories, addresses, loading, error]);
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const value = useContext(StoreContext);
  if (!value) throw new Error('useStore must be used inside StoreProvider');
  return value;
}

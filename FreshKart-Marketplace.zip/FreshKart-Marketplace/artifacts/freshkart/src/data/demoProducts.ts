import bananaImage from '../assets/bananas.jpg';
import appleImage from '../assets/apples.jpg';
import orangeImage from '../assets/oranges.jpg';
import grapeImage from '../assets/grapes.jpg';

export interface Category {
  id: string;
  name: string;
  slug: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  category_id: string;
  category_name: string;
  price_cents: number;
  unit: string;
  stock: number;
  is_active: boolean;
  image_url: string;
}

export const demoCategories: Category[] = [
  { id: 'everyday', name: 'Everyday fruit', slug: 'everyday-fruit' },
  { id: 'citrus', name: 'Citrus & sunshine', slug: 'citrus' },
  { id: 'seasonal', name: 'Seasonal picks', slug: 'seasonal' },
];

export const demoProducts: Product[] = [
  { id: 'banana', name: 'Robusta bananas', slug: 'robusta-bananas', description: 'Naturally sweet, just-right ripe bananas from local growers.', category_id: 'everyday', category_name: 'Everyday fruit', price_cents: 4800, unit: 'dozen', stock: 34, is_active: true, image_url: bananaImage },
  { id: 'apple', name: 'Kinnaur apples', slug: 'kinnaur-apples', description: 'A crisp mountain apple with a bright, clean finish.', category_id: 'seasonal', category_name: 'Seasonal picks', price_cents: 14500, unit: 'kg', stock: 18, is_active: true, image_url: appleImage },
  { id: 'orange', name: 'Nagpur oranges', slug: 'nagpur-oranges', description: 'Juicy, fragrant oranges picked for their lovely tang.', category_id: 'citrus', category_name: 'Citrus & sunshine', price_cents: 8200, unit: 'kg', stock: 22, is_active: true, image_url: orangeImage },
  { id: 'grapes', name: 'Black seedless grapes', slug: 'black-seedless-grapes', description: 'Small-batch, tender grapes with a deep, honeyed sweetness.', category_id: 'seasonal', category_name: 'Seasonal picks', price_cents: 12600, unit: '500 g', stock: 11, is_active: true, image_url: grapeImage },
  { id: 'banana-2', name: 'Yelakki bananas', slug: 'yelakki-bananas', description: 'Little aromatic bananas, lovely for a lunchbox or a snack.', category_id: 'everyday', category_name: 'Everyday fruit', price_cents: 6900, unit: 'dozen', stock: 15, is_active: true, image_url: bananaImage },
  { id: 'orange-2', name: 'Sweet lime', slug: 'sweet-lime', description: 'Mild, mellow citrus for fresh juice and sunny afternoons.', category_id: 'citrus', category_name: 'Citrus & sunshine', price_cents: 7400, unit: 'kg', stock: 20, is_active: true, image_url: orangeImage },
];
